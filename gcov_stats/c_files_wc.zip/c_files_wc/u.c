foo (a, b) { return a % b; }
