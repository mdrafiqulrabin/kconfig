foo (long long *p)
{
  p[0] = p[1];
}
