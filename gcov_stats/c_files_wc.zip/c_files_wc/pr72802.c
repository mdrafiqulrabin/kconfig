static a[];
static b, h, m, n, o, p, q, t, u, v, t5, t6, t16, t17, t18, t25;
c;
static volatile d;
static volatile e;
static volatile f;
static volatile g;
j;
static volatile k;
static volatile l;
static volatile r;
const volatile s;
static volatile w;
static volatile x;
const volatile y;
static volatile z;
static volatile t1;
static volatile t2;
const t3;
t4;
const volatile t8;
const volatile t9;
const volatile t10;
static volatile t11;
static volatile t12;
static volatile t13;
static volatile t14;
const volatile t15;
static volatile t19;
static volatile t20;
const volatile t21;
static volatile t22;
static volatile t23;
const volatile t24;
*t29;
fn1() { b = 5; }
fn2(long);
#pragma pack(1)
struct S0 {
  short f3;
  float f4;
  signed f5
};
const struct S0 t7[] = {};
static fn3() {
  int t26[] = {};
  int t27[10] = {};
  --t25;
  if (fn4()) {
    t5++;
    fn5();
    int t28[] = {t26, t27};
    return;
  }
}
fn6() {
  int i, t30 = 0;
  if (fn6 == 2)
    t30 = 1;
  {
    int t31, i = 0;
    for (; i < 256; i++) {
      t31 = i;
      if (i & 1)
        t31 = 0;
      a[i] = t31;
    }
    i = 0;
    for (; i < 3; i++)
      t29[i] = t6;
    fn7();
    fn3();
    t4 = c = j = 0;
  }
  fn2(h);
  if (t30)
    printf(b);
  g;
  fn2(g);
  printf(b);
  f;
  fn2(f);
  if (t30)
    printf(b);
  e;
  fn2(e);
  printf(b);
  fn8();
  d;
  fn2(d);
  if (t30)
    printf(b);
  l;
  fn2(l);
  printf(b);
  k;
  fn2(k);
  if (t30)
    printf(b);
  printf(b);
  for (; i; i++) {
    y;
    fn2(y);
    printf(b);
    x;
    fn2(x);
    if (t30)
      printf(b);
    w;
    fn2(w);
    printf(b);
    fn2(v);
    printf(b);
    fn2(u);
    if (t30)
      printf(b);
    fn2(t);
    printf(b);
    s;
    fn2(s);
    if (t30)
      printf(b);
    r;
    fn2(r);
    printf(b);
    fn2(q);
    if (t30)
      printf(b);
    fn2(p);
    printf("", b);
    fn2(o);
    printf(b);
    fn2(n);
    if (t30)
      printf(b);
    fn2(m);
    printf(b);
  }
  fn2(z);
  if (t30)
    printf(b);
  printf("", t3);
  t2;
  fn2(t2);
  printf(b);
  t1;
  fn2(t1);
  if (t30)
    printf(b);
  for (; i < 6; i++) {
    t10;
    fn2(t10);
    printf(b);
    t9;
    fn2(t9);
    if (t30)
      printf(b);
    t8;
    fn2(t8);
    printf(b);
    fn2(t7[i].f3);
    if (t30)
      printf(b);
    fn2(t7[i].f4);
    printf(b);
    fn2(t7[i].f5);
    if (t30)
      printf(b);
    t15;
    fn2(t15);
    printf(b);
    t14;
    fn2(t14);
    if (t30)
      printf(b);
    t13;
    fn2(t13);
    printf(b);
    t12;
    fn2(t12);
    if (t30)
      printf(b);
    t11;
    fn2(t11);
    printf(b);
    t21;
    fn2(t21);
    if (t30)
      printf(b);
    t20;
    fn2(t20);
    fn2(t19);
    if (t30)
      printf(b);
    fn2(t18);
    printf(b);
    fn2(t17);
    printf(b);
    fn2(t16);
    printf(b);
  }
  t24;
  t24;
  if (t30)
    printf(b);
  printf(t23);
  t22;
  t22;
  if (t30)
    printf(b);
}
