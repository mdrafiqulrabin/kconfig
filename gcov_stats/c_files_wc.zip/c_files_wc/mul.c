void
mulqi (char *p, char a, char b)
{
  p[0] = a/b;
}
