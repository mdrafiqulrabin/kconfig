#define X(x) x
int main() { return X(0/* *//* */); }
