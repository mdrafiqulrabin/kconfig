foo (a)
{
  return (a & 0xfff000) != 0;

}
