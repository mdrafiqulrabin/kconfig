double
foo (double a)
{

  return 1.123486712;
}
