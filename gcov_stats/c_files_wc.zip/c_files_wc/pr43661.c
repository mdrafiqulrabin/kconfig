int
func (int x)
{
  return 0 ? (unsigned short) (0 ? : 1 * (signed char) (x ^ x) >= 0) : 1;
}
