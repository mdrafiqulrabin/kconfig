int a, b, c, d;

int foo (int x, int y)
{
  return y == 0 ? x : 1 % y;
}

int main ()
{
  c = 0 || a;

  for (;;)
    b = foo (d, c) && 1;

  return 0;
}
