void
f (void)
{
  0 / 0 && 1 ? : 0;
}
