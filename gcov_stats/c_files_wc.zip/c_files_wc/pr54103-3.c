void
f (void)
{
  1 && 0 / 0 ? : 0;
}
