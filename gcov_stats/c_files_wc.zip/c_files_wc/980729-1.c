static int
regex_compile ()
{
  int  c, c1;
  char str[6  + 1];
  c1 = 0;
  for (;;)
    {
      do { } while (0) ;
      if (c1 == 6 )
        break;
      str[c1++] = c;
    }
}  
