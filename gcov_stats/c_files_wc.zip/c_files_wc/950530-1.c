f (int *s, int *t)
{
  return (t - s) / 2;
}
