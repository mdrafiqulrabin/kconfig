int f = (_Complex float)(0.5) == 0.5;

