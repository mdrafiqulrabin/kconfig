foo (int *p)
{
  p[10] = 0;
}
