foo (a)
{
  return a * 5 + 12;
}
