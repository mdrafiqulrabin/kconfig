int
foo (int i, unsigned short j)
{
  return j *= i;
}
