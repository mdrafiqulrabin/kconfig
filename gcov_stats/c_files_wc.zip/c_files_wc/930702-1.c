f ()
{
  {({});}
  return 1;
}
