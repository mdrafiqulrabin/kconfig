char l7_en;
long long l6_data_Z_0th;
int t;
void f()
{
  if (((char )(l6_data_Z_0th>>1 & 1U)) & ((l6_data_Z_0th & 1U)
     | !(((char )(l6_data_Z_0th>>35 & 15U))==14U)))
    t = 0ULL;
}

