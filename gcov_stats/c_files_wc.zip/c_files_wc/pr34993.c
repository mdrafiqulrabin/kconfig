/* PR c/34993 */

/* { dg-do compile } */

typedef int x[] __attribute((may_alias));
