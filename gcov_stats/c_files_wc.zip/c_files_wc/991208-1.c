void fn (char *ptr)
{
  void *p = ptr - 8 - 4;
}
