foo (a)
{
  return a | 0xffff0101;
}
