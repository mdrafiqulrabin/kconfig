struct s
{
  int f;
};

struct s
f ()
{
  int addr;
  return *(struct s *) &addr;
}
