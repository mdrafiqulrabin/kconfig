f ()
{
  do
    {
      if (0)
	{
        L1:;
	}
      else
	goto L2;
    L2:;
    }
  while (0);

  goto L1;
}
