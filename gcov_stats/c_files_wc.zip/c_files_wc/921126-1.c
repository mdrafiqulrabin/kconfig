f()
{
  long long a0, a1, a0s, val;
  int width;
  float d;
  if (d)
    ;
  if (a0s & (1LL << width))
    ;
  return a0 / a1;
}
