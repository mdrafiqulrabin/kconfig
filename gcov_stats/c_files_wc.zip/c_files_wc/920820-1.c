long long f(double y){return y;}
