int
bar (int i)
{
  return 1 | ((i * 2) & 254);
}
