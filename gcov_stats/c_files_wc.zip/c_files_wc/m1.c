foo (p)
     int *p;
{
  *p = 1234;
}
