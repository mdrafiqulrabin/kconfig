f(){double*xp,y;*xp++=sqrt(y);}
