x(int*p){int x=p;}
