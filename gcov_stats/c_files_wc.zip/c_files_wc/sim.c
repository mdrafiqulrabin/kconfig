main ()
{
  int i;

  for (i = 1;  i < 10000; i++)
    ;
}
