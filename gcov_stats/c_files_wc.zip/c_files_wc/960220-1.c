f ()
{
  unsigned long long int a = 0, b;
  while (b > a)
    ;
}
