foo (int *p)
{
  int a = *p;
  return a >> 24;
}
