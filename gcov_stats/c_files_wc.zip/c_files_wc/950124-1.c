f ()
{
  if (g ())
    h ();
  else
    {
      do
	{
	  return 0;
	  break;
	}
      while (1);
    }
  return 1;
}
