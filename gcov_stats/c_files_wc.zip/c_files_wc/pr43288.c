static int a __attribute__ ((common));
