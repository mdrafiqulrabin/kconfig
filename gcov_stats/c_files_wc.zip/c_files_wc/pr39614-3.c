int i;
void
f (void)
{
  i = (1 ? 1 / 0 : 1 / 0);
}
