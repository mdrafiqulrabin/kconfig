f()
{
  struct { char x; } r;
  g(r);
}
