x(){char*q;return(long)q>>8&0xff;}
