static void
__bb_init_prg ()
{
  const char *p;

      {
	unsigned long l;

	(__extension__ (__builtin_constant_p (p) && __builtin_constant_p (l)
			? 5 : 2));
      }

}
