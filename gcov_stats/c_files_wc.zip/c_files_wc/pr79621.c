int b5;

void
h6 (int zb, int e7)
{
  while (b5 > 0)
    {
      int gv;

      for (gv = 1; gv < 4; ++gv)
        {
          ((zb != 0) ? b5 : gv) && (b5 /= e7);
          zb = 0;
        }
      e7 = 0;
    }
}

