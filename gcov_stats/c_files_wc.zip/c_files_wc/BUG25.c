
foo (a)
{
  __builtin_ffs (a);
}
